# MusicApi.Song

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | Song ID | [optional] 
**title** | **String** | Song title | [optional] 
**artist** | **String** | Song artist | [optional] 


