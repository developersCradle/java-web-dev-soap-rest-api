# MusicApi.PlaylistWithSongs

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** | ID of the playlist | [optional] 
**name** | **String** | Name of the playlist | [optional] 
**song** | [**[Song]**](Song.md) | Song in the playlist | [optional] 


