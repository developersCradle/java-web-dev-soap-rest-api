# MusicApi.NewPlaylist

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Playlist name | [optional] 
**songIds** | **[Number]** | IDs of the songs in the playlist | [optional] 


